from nose.plugins import Plugin

class ExamplePlugin(Plugin):
    pass
